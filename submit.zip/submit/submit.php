<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SEdb Submit</title>
	
	<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="../public/css/header.css">
	<link rel="stylesheet" href="../public/css/footer.css"/>

</head>
<body>
  
<header>
	<nav class="navbar main-menu" style="background-color:black;">
		<div class="container">
			<div class="navbar-header">
				<a class="navbar-brand" href="../index.php"><img class="logo" id="logo" src="../public/img/logo.png" alt="logo"></a>
			</div>

			<!-- navbar-collapse start-->
			<div id="nav-menu" class="navbar-collapse collapse" role="navigation">
				<ul class="nav navbar-nav menu-wrapper">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../data-browse.php">Data-Browse</a></li>
					<li><a href="../search.php">Search</a></li>
					<li>
						<a href="#" data-toggle="dropdown">Analysis<b class="caret"></b></a>
						<ul class="dropdown-menu" style="background-color:black;">
							<li><a href="../analysis_gene.php">GENE-SE Analysis</a></li>
							<li><a href="../analysis_snp.php">SNP-SE Analysis</a></li>
							<li><a href="../analysis_overlap.php">Overlap Analysis</a></li>
						</ul>
					</li>
					<li><a href="../genome-growser.php">Genome-Browser</a></li>			   
					<li><a href="../download.php">Download</a></li>	
					<li><a href="../statistics.php">Statistics</a></li>
					<li class="active"><a href="../submit.php">Submit</a></li>
					<li><a href="../contact.php">Contact</a></li>
					<li><a href="../help.php">Help</a></li>
				</ul>
			</div>

		</div>
	</nav>
</header>

<?php
	ini_set("error_reporting","E_ALL & ~E_NOTICE");
	include '../../sqlconfig/my/conn.php';

	$biosample_type=empty($_POST['biosample_type'])?null:trim($_POST['biosample_type']);
	$tissue_type=empty($_POST['tissue_type'])?null:trim($_POST['tissue_type']);
	$biosample_name=empty($_POST['biosample_name'])?null:trim($_POST['biosample_name']);
	$pubmed_id=empty($_POST['pubmed_id'])?null:trim($_POST['pubmed_id']);

	$h3k27ac_loc=empty($_POST['h3k27ac_loc'])?null:trim($_POST['h3k27ac_loc']);
	$input_loc=empty($_POST['input_loc'])?null:trim($_POST['input_loc']);

	$user_name=empty($_POST['user_name'])?null:trim($_POST['user_name']);
	$user_mail=empty($_POST['user_mail'])?null:trim($_POST['user_mail']);
	$description=empty($_POST['description'])?null:trim($_POST['description']);

	$submit_sample_sql="INSERT INTO submit 
			(biosample_type,tissue_type,biosample_name,pubmed_id,h3k27ac_loc,input_loc,user_name,user_mail,description)
			values ('".$biosample_type."','".$tissue_type."','".$biosample_name."','".$pubmed_id."','".$h3k27ac_loc."','".$input_loc."','".$user_name."','".$user_mail."','".$description."')
		";
	$submit_sample_res=mysql_query($submit_sample_sql,$conn); 
?>


<div class="container-fluid">
	<div class="row">
		<div class="col-lg-5 col-md-offset-6">
			<ol class="breadcrumb text-right" style="background-color:#ffffff;">
				<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
				<li><a href="submit.php">Submit</a></li>
			</ol>
		</div>
	</div>	

	<div class="row">
		<div class="col-lg-10 col-md-offset-1" style="height:1000px;">
			<center>	
				<h1>Submitted successfully</h1>
				<h3>Thank you for the data submitted, we need to review before we can pass.</h3>
				<img src="../public/img/submit/submit_thanks.jpg" height="800px" width="1000px">
			</center>								
		</div>

	</div>
</div>
<footer>
	  <p><a href="../index.php">Home</a> | <a href="../data-browse.php">Data-Browse</a> | <a href="../search.php">Search</a> | <a href="../analysis_snp.php">Analysis</a>  |  <a href="../genome-growser.php">Genome-Browser</a> | <a href="../download.php">Download</a> | <a href="../statistics.php">Statistics</a> | <a href="../submit.php">Submit</a> | <a href="../contact.php">Contact</a> | <a href="../help.php">Help</a></p>
      <p>Copyright &copy; HMU | <a href="http://www.licpathway.net//" target="_blank"><font size="4" color="red">Li C Lab</a></a></p>
</footer>
  </body>
</html>