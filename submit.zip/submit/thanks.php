<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SEdb Submit</title>
	
	<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="../public/css/header.css">
	<link rel="stylesheet" href="../public/css/footer.css"/>

</head>
<body>
  
<header>
	<nav class="navbar main-menu" style="background-color:black;">
		<div class="container">
			<div class="navbar-header">
				<a class="navbar-brand" href="../index.php"><img class="logo" id="logo" src="../public/img/logo.png" alt="logo"></a>
			</div>

			<!-- navbar-collapse start-->
			<div id="nav-menu" class="navbar-collapse collapse" role="navigation">
				<ul class="nav navbar-nav menu-wrapper">
					<li><a href="../index.php">Home</a></li>
					<li><a href="../data-browse.php">Data-Browse</a></li>
					<li><a href="../search.php">Search</a></li>
					<li>
						<a href="#" data-toggle="dropdown">Analysis<b class="caret"></b></a>
						<ul class="dropdown-menu" style="background-color:black;">
							<li><a href="../analysis_gene.php">GENE-SE Analysis</a></li>
							<li><a href="../analysis_snp.php">SNP-SE Analysis</a></li>
							<li><a href="../analysis_overlap.php">Overlap Analysis</a></li>
						</ul>
					</li>
					<li><a href="../genome-growser.php">Genome-Browser</a></li>			   
					<li><a href="../download.php">Download</a></li>	
					<li><a href="../statistics.php">Statistics</a></li>
					<li class="active"><a href="../submit.php">Submit</a></li>
					<li><a href="../contact.php">Contact</a></li>
					<li><a href="../help.php">Help</a></li>
				</ul>
			</div>

		</div>
	</nav>
</header>

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-5 col-md-offset-6">
			<ol class="breadcrumb text-right" style="background-color:#ffffff;">
				<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
				<li><a href="submit.php">Submit</a></li>
			</ol>
		</div>
	</div>	

	<div class="row">
		<div class="col-lg-10 col-md-offset-1">
			 <div class="alert alert-info" role="alert" style="height:1000px;">
			 		<center>
						<h1>Thank you</h1>
						<h4>We are very grateful to the sharers who contributed to the SEdb update, and we sincerely thank the providers of the source of the samples collected by SEdb.</h4><br/><br/><br/>
						<h4>List of sharers</h4>
					</center>
 				</div>
			
							
		</div>

	</div>
</div>
<footer>
	  <p><a href="../index.php">Home</a> | <a href="../data-browse.php">Data-Browse</a> | <a href="../search.php">Search</a> | <a href="../analysis_snp.php">Analysis</a>  |  <a href="../genome-growser.php">Genome-Browser</a> | <a href="../download.php">Download</a> | <a href="../statistics.php">Statistics</a> | <a href="../submit.php">Submit</a> | <a href="../contact.php">Contact</a> | <a href="../help.php">Help</a></p>
      <p>Copyright &copy; HMU | <a href="http://www.licpathway.net//" target="_blank"><font size="4" color="red">Li C Lab</a></a></p>
</footer>
  </body>
</html>